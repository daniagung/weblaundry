<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'lWJqxyFIBTGQ1VTOC9GskA');
    define('CONSUMER_SECRET', 'X52rrmbjHLDwGJu7VjzuJgtPfmE5kt3W3HSeTXHwc');

    // User Access Token
    define('ACCESS_TOKEN', '1139429131-KVEYkdtIRA915cmW5hxXfHizo5jiUIrHIgTNULh');
    define('ACCESS_SECRET', 'ZlFa7jtqjM2B0w2A7ZnevOLZ2YwHWNB0vRH3uQugc8c');