<?php
defined('ABSPATH') or die();
/*
Plugin Name: Cleanco Visual Composer Add On
Plugin URI: http://www.detheme.com/
Description: Module add on for WPBakery Visual Composer. Plugin need Visual Composer 4.2.3 or lower
Version: 1.0.0
Author: detheme.com
Author URI: http://www.detheme.com/
*/

include_once(ABSPATH . 'wp-admin/includes/plugin.php');
include_once(ABSPATH . 'wp-admin/includes/class-wp-filesystem-base.php');
include_once(ABSPATH . 'wp-admin/includes/class-wp-filesystem-direct.php');

class DethemeCleancoVC{

    function init(){

      if(!function_exists('vc_set_as_theme'))
        return true;

        global $dt_revealData,$detheme_Style;

        $dt_revealData=array();
        $detheme_Style=array();

        load_plugin_textdomain('detheme', false, dirname(plugin_basename(__FILE__)) . '/languages/');
        define('CLEANCO_VC_BASENAME',dirname(plugin_basename(__FILE__)));
        define('CLEANCO_VC_DIR',plugin_dir_path(__FILE__));
        define('CLEANCO_VC_DIR_URL',plugin_dir_url(__FILE__));

       if(version_compare(WPB_VC_VERSION,"4.2.3",'<')){
          require_once(plugin_dir_path(__FILE__)."lib/map.old.php");
        }
        else{
          require_once(plugin_dir_path(__FILE__)."lib/map.php");
        }

        require_once(plugin_dir_path(__FILE__)."lib/shortcode.php");

        add_action('wp_enqueue_scripts', array($this,'load_front_css_style' ));
        add_action('admin_enqueue_scripts', array($this,'load_editor_css_style' ));
        add_filter( 'plugin_row_meta', array($this,'vc_compatible_version'),1,4);//
        wp_enqueue_script('dt-vc-addon',CLEANCO_VC_DIR_URL.'js/script.js',array('jquery'));

        add_action('wp_ajax_detheme_get_shortcode',array($this,'load_css_style_shortcode_panel'),1);
        add_action('wp_footer',array($this,'load_custom_css_style'),1);

    }

    function load_custom_css_style(){
      global $dt_revealData,$detheme_Style; 

      if(count($dt_revealData)) { print @implode("\n",$dt_revealData);}
      if(count($detheme_Style)){print "<style type=\"text/css\">".@implode("\n",$detheme_Style)."</style>";}

    }


     function vc_compatible_version($plugin_meta, $plugin_file, $plugin_data, $status){

      if('js_composer/js_composer.php'!=$plugin_file)
        return $plugin_meta;
      $plugin_meta=array();

      if ( !empty( $plugin_data['Version'] ) )
        $plugin_meta[] = sprintf( __( 'Version %s' ), $plugin_data['Version'] );
      if ( !empty( $plugin_data['Author'] ) ) {
        $plugin_meta[] = sprintf( __( 'By %s' ), $plugin_data['Author'] );
      }

      return $plugin_meta;
    }


    function load_editor_css_style(){

        wp_enqueue_style('fontello-font',CLEANCO_VC_DIR_URL."fontello/fontello.css");
        wp_enqueue_style( 'detheme-vc-front',CLEANCO_VC_DIR_URL."lib/admin/css/admin.css?".time(),array());
        wp_enqueue_script('icon-picker',CLEANCO_VC_DIR_URL.'lib/admin/js/icon_picker.js',array('jquery'));

        if(version_compare(WPB_VC_VERSION,"4.2.3",'>=')){
           wp_enqueue_script('detheme-vc-backend',CLEANCO_VC_DIR_URL.'lib/admin/js/backend.new.js',array('jquery'));
        }
        do_action('cleanco_load_admin_css_style');
    }

    function load_front_css_style(){

        wp_register_style('fontello-font',CLEANCO_VC_DIR_URL."fontello/fontello.css");
        wp_register_style('detheme-vc',CLEANCO_VC_DIR_URL."css/plugin_style.css",array('fontello-font'));


        wp_register_style('scroll-spy',CLEANCO_VC_DIR_URL."css/scroll_spy.css",array('scroll-spy-ie'));
        wp_register_style( 'scroll-spy-ie', get_template_directory_uri() . '/css/scroll_spy_ie9.css', array());
        wp_style_add_data( 'scroll-spy-ie', 'conditional', 'IE 9' );


        wp_register_script( 'uilkit', CLEANCO_VC_DIR_URL . 'js/uilkit.js', array(), '1.0', false );
        wp_register_script('ScrollSpy',CLEANCO_VC_DIR_URL."js/scrollspy.js",array( 'uilkit' ), '1.0', false );

        wp_enqueue_style( 'detheme-vc');

    }

    function load_css_style_shortcode_panel(){
        wp_enqueue_style('fontello-font',CLEANCO_VC_DIR_URL."fontello/fontello.css");
    }

}

add_action('init', array(new DethemeCleancoVC(),'init'),1);

if(!function_exists('darken')){

    function darken($colourstr, $procent=0) {
      $colourstr = str_replace('#','',$colourstr);
      $rhex = substr($colourstr,0,2);
      $ghex = substr($colourstr,2,2);
      $bhex = substr($colourstr,4,2);

      $r = hexdec($rhex);
      $g = hexdec($ghex);
      $b = hexdec($bhex);

      $r = max(0,min(255,$r - ($r*$procent/100)));
      $g = max(0,min(255,$g - ($g*$procent/100)));  
      $b = max(0,min(255,$b - ($b*$procent/100)));

      return '#'.str_repeat("0", 2-strlen(dechex($r))).dechex($r).str_repeat("0", 2-strlen(dechex($g))).dechex($g).str_repeat("0", 2-strlen(dechex($b))).dechex($b);
    }

}

if(!function_exists('lighten')){

    function lighten($colourstr, $procent=0){

      $colourstr = str_replace('#','',$colourstr);
      $rhex = substr($colourstr,0,2);
      $ghex = substr($colourstr,2,2);
      $bhex = substr($colourstr,4,2);

      $r = hexdec($rhex);
      $g = hexdec($ghex);
      $b = hexdec($bhex);

      $r = max(0,min(255,$r + ($r*$procent/100)));
      $g = max(0,min(255,$g + ($g*$procent/100)));  
      $b = max(0,min(255,$b + ($b*$procent/100)));

      return '#'.str_repeat("0", 2-strlen(dechex($r))).dechex($r).str_repeat("0", 2-strlen(dechex($g))).dechex($g).str_repeat("0", 2-strlen(dechex($b))).dechex($b);
    }

}

if(!function_exists('dt_exctract_DTicon')){

  function dt_exctract_DTicon($file="",$pref=""){

    $wp_filesystem=new WP_Filesystem_Direct(array());

    if(!$wp_filesystem->is_file($file) || !$wp_filesystem->exists($file))
        return false;

     if ($buffers=$wp_filesystem->get_contents_array($file)) {
       $icons=array();

      foreach ($buffers as $line => $buffer) {

        if(preg_match("/^(\.".$pref.")([^:\]\"].*?):before/i",$buffer,$out)){

          if($out[2]!==""){
              $icons[$pref.$out[2]]=$pref.$out[2];
          }
        }
      }
      return $icons;

    }else{

      return false;
    }
  }
}

function get_font_lists($path){

  $wp_filesystem=new WP_Filesystem_Direct(array());

  $icons=array();
  if($dirlist=$wp_filesystem->dirlist($path)){

    foreach ($dirlist as $dirname => $dirattr) {

       if($dirattr['type']=='d'){
          if($dirfont=$wp_filesystem->dirlist($path.$dirname)){
            foreach ($dirfont as $filename => $fileattr) {
              if(preg_match("/(\.css)$/", $filename)){
                if($icon=dt_exctract_DTicon($path.$dirname."/".$filename)){

                  $icons=@array_merge($icon,$icons);
                }
                break;
              }
             
            }
          }
        }
        elseif($dirattr['type']=='f' && preg_match("/(\.css)$/", $dirname)){

          if($icon=dt_exctract_DTicon($path.$dirname)){
              $icons=@array_merge($icon,$icons);
          }

      }

    }
  }
  return $icons;
}

function detheme_font_list(){

  $path=CLEANCO_VC_DIR."fontello/";

  $icons=array();
  if($newicons=get_font_lists($path)){
    $icons=array_merge($icons,$newicons);
  }

  return apply_filters('detheme_font_list',$icons);
}

?>